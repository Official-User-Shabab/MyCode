# Strange Survival Game

Hopefully turning this into a GUI soon!

### GENERAL DESCRIPTION OF GAME ###

Starting with 3 lives, you go through a series of unexpected and out-of-the world-scenarios, and must stay alive at the end to win.
Losing all your lives mean you lose; to replay, restart the program.

### THE ASCII ART ###

If the ASCII Art seems to be printing weird, and you're not artistic enough to fix it, then try allign all the spaces, (or
empty spaces) vertically at the right-most side. For example, type in the 0s (and then delete them later, but ensure no spaces 
are deleted).

       ARTART       0
      ART  ART      0
    ART      ART    0
    ART      ART    0
     ART    ART     0
       ARTART       0
       
See the ASCII Art used in the ASCII ART.txt file: https://github.com/GithubWuMing/Strange-Survival-game/blob/main/ASCII%20ART.txt

#####

### CREDITS ###

See credits text file (CREDITS.txt): https://github.com/GithubWuMing/Strange-Survival-game/blob/main/CREDITS.txt
